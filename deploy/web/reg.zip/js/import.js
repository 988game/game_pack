var gameWebUrl = 'http://intest1.dstars.cc/minigame/guess/index.html'                                    //游戏web地址
var funcReqUrl = 'http://intest.dstars.cc:8002/jccommon'               //接口地址
var downloadUrl = 'http://intest.dstars.cc/club/ddtest/'
var defaultAppStr = 'jcapp'

function getGameUrl() {
    return gameWebUrl;               //web网页地址
}

function getFuncUrl() {
    return funcReqUrl;
}

function getDownloadUrl(){
    return downloadUrl;
}

function getAppStr(){
    return defaultAppStr;
}